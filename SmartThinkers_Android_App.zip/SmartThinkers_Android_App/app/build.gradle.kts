plugins {
    id("com.android.application")
}

android {
    namespace = "com.smartthinkers.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.smartthinkers.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
