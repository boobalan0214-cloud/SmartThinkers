SMART THINKERS ANDROID APP
============================

இந்த ZIP ஒரு Android Studio project.

Project:
- Smart Thinkers
- Civil Construction & Engineering
- Website UI embedded in Android WebView
- WhatsApp / Phone / Email links
- Construction Cost Estimator
- Home Planner
- FAQ
- Project Tracker
- Google Maps embed
- Cinematic animations

BUILD:
1. ZIP-ஐ extract செய்யவும்.
2. Android Studio -> Open -> SmartThinkers folder.
3. Gradle Sync முடியும் வரை காத்திருக்கவும்.
4. Run ▶ அழுத்தி Android phone/emulator-ல் test செய்யவும்.
5. APK உருவாக்க: Build -> Build Bundle(s) / APK(s) -> Build APK(s).

IMPORTANT:
- Internet permission already included.
- Website uses online images, Google Maps and GSAP CDN, so internet is required for those features.
- Contact details are copied from the supplied index.html.
- Before publishing, replace demo/sample company details and add your final logo, privacy policy and store assets.

CONTACT DETAILS CURRENTLY IN THE HTML:
Phone/WhatsApp: 6383326283
Email: boobalan0214@gmail.com
Area: Sivagangai / Pudukkottai and nearby areas
